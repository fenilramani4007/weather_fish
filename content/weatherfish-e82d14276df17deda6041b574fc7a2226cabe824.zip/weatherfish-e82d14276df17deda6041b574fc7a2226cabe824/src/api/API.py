import time
from . import IO
from . import Data
import warnings
from . import geocoder
from . import OpenAIAPI
from fastapi import APIRouter


def get_all_weather_data(cities: list, zipcodes: list = None, person="", hobbies: list = None, language="de"):
    """
    Generates current, hourly and daily weather data using zipcodes saved to the weather_data directory.
    Saves a personalized text output in the weather_text_from_gpt directory and tts converted files in their corresponding directory.
    If no specific person, hobbies and/or language are desired leave the respective parameter(s) empty.
    :param cities: A list of cities
    :param language: OPTIONAL: ISO 639 language code of desired language (Default is german)
    :param hobbies: OPTIONAL: A list of hobbies
    :param person: OPTIONAL: A person in the style of which a text prompt is generated
    :param zipcodes: A list of zipcodes.
    :return:
    """

    if hobbies is None:
        hobbies = ["gaming", "tennis", "fahrrad fahren"]

    if zipcodes is not None:
        coordinate_set = [geocoder.get_coordinates_from_zipcode(zipcode) for zipcode in zipcodes]

    else:
        coordinate_set = [geocoder.get_coordinates_from_city(city) for city in cities]

    if len(cities) != len(zipcodes):
        warnings.warn("The length of the list of cities does not match the length of the list of zipcodes")
        return

    for i in range(len(coordinate_set)):
        long, lat = coordinate_set[i]
        # city = cities[i]

        postcode = zipcodes[i]

        if (long, lat) == (None, None):
            warnings.warn("Received invalid coordinates")
            continue

        # call IO methods to generate all weather data json files
        df_current, df_hourly, df_daily = Data.call_meteo_api(long, lat)
        IO.current_weather(df_current, postcode)
        IO.forecast_weather_hourly(df_hourly, postcode)
        IO.forecast_weather_daily(df_daily, postcode)
        IO.write_structured_json(postcode)

    # generate personalized prompt for every city

    # generate text, save text to txt file and convert to speech
    persons = ["Merkel","Haftbefehl","Fisch"]

    for person in persons:

        text = OpenAIAPI.prompt(cities=cities, person=person, hobbies=hobbies, language=language, zipcodes=zipcodes)
        IO.generate_mp3_from_text(language_code=language, text=text, person=person)

        if person == "Fisch":
            continue

        print("Waiting 30 seconds until next OpenAI request")
        time.sleep(30)

    # Wait if there are more zipcodes to check
    #if len(cities) >= 1 and (i != len(cities) - 1):
    #    print("Waiting 25 seconds until next OpenAI request")
    #    time.sleep(25)