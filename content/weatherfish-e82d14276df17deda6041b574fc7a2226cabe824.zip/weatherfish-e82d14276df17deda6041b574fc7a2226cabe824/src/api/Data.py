import openmeteo_requests
import pandas as pd
import requests_cache
from retry_requests import retry
from . import Helper




def call_meteo_api(lat: float, long: float) -> (pd.Series, pd.DataFrame, pd.DataFrame):
    """
    Takes coordinates and returns the current data, hourly data for one day and daily weather data for one week
    respectively. All time data is in the europe/berlin timezone
    :param lat: latitude of location
    :param long: longitude of location
    :return: A pandas DataFrame for each current, hourly and daily data
    """
    # Set up the Open-Meteo API client with cache and retry on error
    cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
    retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
    openmeteo = openmeteo_requests.Client(session=retry_session)

    # Make sure all required weather variables are listed here
    # The order of variables in hourly or daily is important to assign them correctly below
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": long,
        "forecast_days": 16,
        "daily": ["temperature_2m_max", "temperature_2m_min", "wind_gusts_10m_max", "wind_speed_10m_max",
                  "cloud_cover_mean", "rain_sum", "showers_sum", "snowfall_sum", "precipitation_hours",
                  "precipitation_sum", "precipitation_probability_max", "cloud_cover_max", "cloud_cover_min"],
        "hourly": ["temperature_2m", "relative_humidity_2m", "apparent_temperature", "precipitation_probability",
                   "cloud_cover"],
        "current": ["temperature_2m", "relative_humidity_2m", "precipitation", "rain", "showers", "snowfall",
                    "apparent_temperature", "cloud_cover"],
        "timezone": "Europe/Berlin"
    }
    responses = openmeteo.weather_api(url, params=params)

    # Process first location. Add a for-loop for multiple locations or weather models
    response = responses[0]

    # Current values. The order of variables needs to be the same as requested.
    current = response.Current()

    data = {
        "current_temperature_2m": current.Variables(0).Value(),
        "current_relative_humidity_2m": current.Variables(1).Value(),
        "current_precipitation": current.Variables(2).Value(),
        "current_rain": current.Variables(3).Value(),
        "current_showers": current.Variables(4).Value(),
        "current_snowfall": current.Variables(5).Value(),
        "current_apparent_temperature": current.Variables(6).Value(),
        "cloud_cover": current.Variables(7).Value()
    }
    current_dataframe = pd.DataFrame(data, index=["current"])
    # print(current_dataframe)
    # current_series = pd.Series(data)

    # Process hourly data. The order of variables needs to be the same as requested.
    hourly = response.Hourly()

    hourly_data = {"date": pd.date_range(
        start=pd.to_datetime(hourly.Time(), unit="s", utc=True),
        end=pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
        freq=pd.Timedelta(seconds=hourly.Interval()),
        inclusive="left"
    ),
        "temperature_2m": hourly.Variables(0).ValuesAsNumpy(),
        "relative_humidity_2m": hourly.Variables(1).ValuesAsNumpy(),
        "apparent_temperature": hourly.Variables(2).ValuesAsNumpy(),
        "precipitation_probability": hourly.Variables(3).ValuesAsNumpy(),
        "cloud_cover": hourly.Variables(4).ValuesAsNumpy()}

    hourly_dataframe = pd.DataFrame(data=hourly_data)

    # Process daily data. The order of variables needs to be the same as requested.
    daily = response.Daily()

    daily_data = {"date": pd.date_range(
        start=pd.to_datetime(daily.Time(), unit="s", utc=True),
        end=pd.to_datetime(daily.TimeEnd(), unit="s", utc=True),
        freq=pd.Timedelta(seconds=daily.Interval()),
        inclusive="left"
    ),
        "temperature_2m_max": daily.Variables(0).ValuesAsNumpy(),
        "temperature_2m_min": daily.Variables(1).ValuesAsNumpy(),
        "wind_gusts_10m_max": daily.Variables(2).ValuesAsNumpy(),
        "wind_speed_10m_max": daily.Variables(3).ValuesAsNumpy(),
        "cloud_cover_mean": daily.Variables(4).ValuesAsNumpy(),
        "rain_sum": daily.Variables(5).ValuesAsNumpy(),
        "showers_sum": daily.Variables(6).ValuesAsNumpy(),
        "snowfall_sum": daily.Variables(7).ValuesAsNumpy(),
        "precipitation_hours": daily.Variables(8).ValuesAsNumpy()
    }

    daily_dataframe = pd.DataFrame(data=daily_data)

    return prep_data(current_dataframe, hourly_dataframe, daily_dataframe)


def prep_data(current: pd.DataFrame, hourly: pd.DataFrame, daily: pd.DataFrame) -> (
        pd.DataFrame, pd.DataFrame, pd.DataFrame):
    """
    Does finishing touches on the weather data for easier use later on
    :param current: current weather data as a pandas series
    :param hourly: hourly weather data as a pandas dataframe
    :param daily: daily weather data as a pandas dataframe
    :return: cleaned up versions of current, hourly, daily datatypes
    """
    current.dropna(inplace=True)
    hourly.dropna(inplace=True)
    daily.dropna(inplace=True)

    # copies due to warning after moving code blocks around
    # open-meteo can deliver nan values for distant future entries --> cant change dtype to int
    # rearrange code to first restrict all dataframes to their respective length
    # this caused a warning in pandas --> ensure you work with the entire original dataframe via .copy()
    current = current.copy()
    hourly = hourly.copy()
    daily = daily.copy()
    # restrict hourly dataframe timeframe to 24 hours
    # get current timestamp in utc+2
    current_time = pd.Timestamp.utcnow()
    current_time.strftime('%Y-%m-%d %H:%M:%S')
    current_time += pd.Timedelta(hours=2)

    # drop all entries which are in the past
    hourly.drop(hourly.loc[hourly['date'] < current_time].index, inplace=True)
    hourly = hourly.iloc[:24]
    hourly['date'] = hourly['date'].dt.hour
    hourly['date'] = hourly['date'].astype(str)

    # restrict daily dataframe to 14 days and change date format
    current_time.strftime('%Y-%m-%d')
    current_time += pd.Timedelta(days=1)
    daily.drop(daily.loc[daily['date'] < current_time].index, inplace=True)
    # daily = daily.iloc[:7]
    daily['date'] = daily['date'].dt.strftime('%Y-%m-%d')

    # round all temperatures
    current_dict = {'current_temperature_2m': 'int', 'current_apparent_temperature': 'int',
                    'current_relative_humidity_2m': 'int'}
    hourly_dict = {'temperature_2m': 'int', 'relative_humidity_2m': 'int', 'apparent_temperature': 'int'}
    daily_dict = {'temperature_2m_max': 'int', 'temperature_2m_min': 'int', 'wind_gusts_10m_max': 'int',
                  'wind_speed_10m_max': 'int'}

    hourly = hourly.astype(hourly_dict)
    daily = daily.astype(daily_dict)
    current = current.astype(current_dict)

    # create new columns for overcast and precipitation
    daily['overcast'] = daily.apply(lambda row: Helper.meancloudcover(row['cloud_cover_mean']), axis=1)
    hourly['overcast'] = hourly.apply(lambda row: Helper.meancloudcover(row['cloud_cover']), axis=1)
    current['overcast'] = current.apply(lambda row: Helper.meancloudcover(row['cloud_cover']), axis=1)

    current['current_precipitation'] = current.apply(
        lambda row: Helper.precipitation(row['current_precipitation'], row['current_rain'], row['current_snowfall']),
        axis=1)

    daily['precipitation'] = daily.apply(
        lambda row: Helper.precipitation(row['rain_sum'], row['showers_sum'], row['snowfall_sum']),
        axis=1)

    # drop columns
    current.drop(
        columns=['cloud_cover', 'current_showers', 'current_rain', 'current_snowfall'],
        inplace=True)
    daily.drop(columns=['cloud_cover_mean', 'rain_sum', 'showers_sum', 'snowfall_sum', 'precipitation_hours'],
               inplace=True)
    hourly.drop(columns=['cloud_cover'], inplace=True)

    # rename all columns
    hourly.rename(columns={'date': 'time', 'temperature_2m': 'temperature', 'apparent_temperature_2m': 'feels like',
                           'relative_humidity_2m': 'humidity',
                           'precipitation_probability': 'precipitation probability'}, inplace=True)
    daily.rename(
        columns={'temperature_2m_max': 'maxtemp', 'temperature_2m_min': 'mintemp', 'wind_gusts_10m_max': 'maxwindgusts',
                 'wind_speed_10m_max': 'maxwindspeed'}, inplace=True)

    current.rename(columns={'current_temperature_2m': 'temperature', 'current_apparent_temperature': 'feels like',
                            'current_relative_humidity_2m': 'humidity'},
                   inplace=True)

    return current, hourly, daily
