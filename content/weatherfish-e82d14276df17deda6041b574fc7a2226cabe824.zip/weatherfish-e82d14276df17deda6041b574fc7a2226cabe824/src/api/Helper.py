def precipitation(precipitation, rain, shower):
    if precipitation > 0 or rain > 0 or shower > 0:
        return "rain"
    return ""


def meancloudcover(mean):
    meanovercast = "clear"

    if 10 < mean <= 40:
        meanovercast = "partly cloudy"

    if 40 < mean:
        meanovercast = "cloudy"

    return meanovercast

