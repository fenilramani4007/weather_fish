import json
from gtts import gTTS
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PATH_TO_FRONTEND = os.path.join(BASE_DIR, "..", "frontend", "public")
PATH_TO_API_DATA = "weather_data/"




def write_to_json(data: dict, file_name: str):
    with open(f"{file_name}.json", "w") as f:
        print(f"{file_name}.json")
        json.dump(data, f, default=str)


def current_weather(df, zipcode):
    data = df.to_dict('index')
    data2 = data["current"]
    write_to_json(data2, f"api/weather_data/{zipcode}_current")


def forecast_weather_daily(df, zipcode):
    # create weekone and weektwo dataset
    weekone = df.iloc[:7]
    weektwo = df.iloc[7:]
    data = weekone.set_index('date').to_dict('index')
    data2 = weektwo.set_index('date').to_dict('index')

    write_to_json(data, f"api/weather_data/{zipcode}_daily_weekone")
    write_to_json(data2, f"api/weather_data/{zipcode}_daily_weektwo")


def forecast_weather_hourly(df, zipcode):
    data = df.set_index('time').to_dict('index')
    write_to_json(data, f"api/weather_data/{zipcode}_hourly")


def get_dict_from_json(zipcodes, cities):
    """
    Reads all json files for a given zipcode and returns the content of each
    :param cities: list of cities
    :param zipcodes: list of all zipcodes
    :return: Dict containing all weather data for every city
    """

    data = {}

    for i in range(len(zipcodes)):
        zipcode = zipcodes[i]
        city = cities[i]

        filename = os.path.join(PATH_TO_FRONTEND, "structured_data", f"{zipcode}_structured.json")
        if os.path.exists(filename):
            with open(filename, "r", encoding="utf-8") as f:
             data[f'{zipcode}_{city}'] = json.load(f)


    return data



def write_structured_json(zipcode):
    filenames = ["current", "hourly", "daily_weekone", "daily_weektwo"]
    data = {}
    for filename in filenames:
        with open(f"api/weather_data/{zipcode}_{filename}.json") as f:
            data[filename] = json.load(f)

    structured_path = os.path.join(PATH_TO_FRONTEND, "structured_data")
    os.makedirs(structured_path, exist_ok=True)

   
    with open(os.path.join(structured_path, f"{zipcode}_structured.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)




def write_prompt_to_txt(data, person):
    path = os.path.join(PATH_TO_FRONTEND, "weather_text_from_gpt")
    os.makedirs(path, exist_ok=True)

    with open(os.path.join(path, f"{person}.txt"), "w", encoding='utf-8') as f:
        f.write(data)




def generate_mp3_from_text(language_code: str, text: str, person):
    """
    Convert text to speech and save in a file named after the zipcode
    :param person: The person in the style of which the text was genereated
    :param language_code: ISO 639 language code (i.e. de, en, ru)
    :param text: content to be converted
    :return:
    """
    speech_path = os.path.join(PATH_TO_FRONTEND, "speech")
    os.makedirs(speech_path, exist_ok=True)


    myobj = gTTS(text=text, lang=language_code, slow=False)
    myobj.save(os.path.join(speech_path, f"{person}.mp3"))

