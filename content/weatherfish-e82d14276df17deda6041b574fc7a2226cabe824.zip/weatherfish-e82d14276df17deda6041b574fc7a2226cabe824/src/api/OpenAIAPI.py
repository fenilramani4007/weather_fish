from . import IO
from openai import OpenAI


api_key = "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"
#api_key2 = "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"
api_key_new = "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"
api_key_newest = "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"
client = OpenAI(
    api_key = api_key_newest
    )


def prompt(cities: list, person: str, hobbies: list, language: str, zipcodes: list):
    """
    Prompt chatgpt with the weather data for a specific location. The prompt is in the style of a given Person.
    The output is written in a zipcode.txt file in the weather_text_from_gpt folder
    :param zipcodes: All zipcodes
    :param language: Desired output language
    :param hobbies: List of hobbies to personalize the prompt
    :param cities: All cities
    :param person: Best case a widely known person in the style of which the output should be.
    :return: 
    """
    data = IO.get_dict_from_json(zipcodes, cities)

    prompt_str = f"I have several json files with weather data. This is the data for the corresponding city. format is zipcode_cityname use the cityname: {str(data)}. "
    prompt_str += f"The report is personalized for someone who has the following hobbies {hobbies} " if len(
        hobbies) > 1 else " "

    prompt_str += f"The ISO 639 language code is {language}. Write a report in that language. "
    prompt_str += f" in the style of {person}. " if len(person) > 0 else ". "
    prompt_str += ("The text should in every case be completely formulated and not in bullet points. "
                   "Also start with the report immediately instead of any confirmation of this prompt. "
                   "Total of 5 sentences. The first sentence serves as an introduction. one sentence for each json file")
    print(prompt_str)

    response = client.responses.create(
        model="gpt-4o-mini",
        input=prompt_str,
    )

    # print(response.output_text)
    IO.write_prompt_to_txt(response.output_text, person)

    return response.output_text

