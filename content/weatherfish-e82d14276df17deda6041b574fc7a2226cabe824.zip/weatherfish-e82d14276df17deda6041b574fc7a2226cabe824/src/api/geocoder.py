import time
import urllib.request, json

from geopy.geocoders import Nominatim

geolocator = Nominatim(user_agent="zipcode_geocoder")


def get_coordinates_from_zipcode(zipcode):
    """
    get_coordinates takes a zipcode and returns the coordinates of the location
    :param zipcode: zipcode of location
    :return:: tuple of latitude and longitude of location
    """
    location = geolocator.geocode(f"{zipcode}, Deutschland")
    time.sleep(2)
    if location:
        return location.latitude, location.longitude
    else:
        return None, None

def get_coordinates_from_city(city_name: str):
    with urllib.request.urlopen(
            f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&countryCode=DE&count=1") as url:
        data = json.load(url)
        #print(data)

    result = data['results'][0]
    print(result['latitude'], result['longitude'])
    return result['latitude'], result['longitude']