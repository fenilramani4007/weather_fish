from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from api import API  
import uvicorn

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/generate-documents")
async def generate_documents(request: Request):
    try:
        payload = await request.json()

        cities = payload.get("cities", [])
        zipcodes = payload.get("zipcodes", [])
        person = payload.get("person", "")
        hobbies = payload.get("hobbies", [])
        language = payload.get("language", "de")

        print("Starte Wetterdatengenerierung...")
        API.get_all_weather_data(cities, zipcodes, person, hobbies, language)

        return {"status": "success", "message": "Wetterdaten wurden erzeugt."}

    except Exception as e:
        import traceback
        print("Fehler während generate_documents:")
        traceback.print_exc()
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    uvicorn.run("api.main:app", host="127.0.0.1", port=8000, reload=True)
