import API
zipcodes = [92224,90402]
cities = ["Amberg","Nuernberg"]
hobbies = ["gaming", "tennis", "fahrrad fahren"]

API.get_all_weather_data(cities=cities,zipcodes=zipcodes, person="Haftbefehl", hobbies=hobbies)


'''
#Dieser Code wird eine warning hervorrufen, weil die beiden listen cities und zipcodes nicht gleich lang sind
zipcodes = [92224]
cities = ["Amberg", "Nürnberg"]

API.get_all_weather_data(cities=cities,zipcodes=zipcodes, person="Haftbefehl", hobbies=hobbies)
'''


#import Helper
#print(Helper.precipitation(1, 2, 1))
