import React, { useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { WeatherProvider } from './contexts/WeatherContext';
import { LocationProvider } from './contexts/LocationContext';
import Layout from './components/Layout';
import './App.css';

function App() {
    // Aktuellen Standortindex verwalten (0–3)
    const [selectedIndex, setSelectedIndex] = useState<number>(0);

    return (
        <Router>
            <LocationProvider>
                <WeatherProvider>
                    {/* Layout bekommt selectedIndex und setSelectedIndex als Props */}
                    <Layout
                        selectedIndex={selectedIndex}
                        setSelectedIndex={setSelectedIndex}
                    />
                </WeatherProvider>
            </LocationProvider>
        </Router>
    );
}

export default App;
