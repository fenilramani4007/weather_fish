import React, { useState } from 'react';
import { CloudSun, Plus, Menu, X } from 'lucide-react';
import { useLocation } from '../contexts/LocationContext';

const Header: React.FC = () => {
  const { currentLocation, savedLocations, setCurrentLocation } = useLocation();
  const [showCityMenu, setShowCityMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  // Format current date in German
  const currentDate = new Date().toLocaleDateString('de-DE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <>
      <header className="bg-blue-500 text-white rounded-t-2xl p-4 w-full lg:w-[calc(100vw-40px)] lg:ml-[-56vw] relative lg:left-1/2">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2 lg:space-x-4">
            <div className="flex items-center">
              <CloudSun size={24} className="mr-2 lg:mr-2" />
              <h1 className="text-xl lg:text-2xl font-bold">APWWS</h1>
            </div>
          </div>

          {/* Desktop center content */}
          <div className="text-center flex-1 mx-4 hidden lg:block">
            <p className="text-sm">
              {currentDate} - {currentLocation?.name || 'Kein Standort ausgewählt'}
            </p>
          </div>

          {/* Mobile location display */}
          <div className="text-center flex-1 mx-2 block lg:hidden">
            <p className="text-xs truncate">
              {currentLocation?.name || 'Kein Standort'}
            </p>
          </div>

          {/* Desktop buttons */}
          <div className="hidden lg:flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-blue-600 transition">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
            </button>
            <button className="p-2 rounded-full hover:bg-blue-600 transition">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </button>
          </div>

          {/* Mobile menu button */}
          <button 
            className="lg:hidden p-2 rounded-full hover:bg-blue-600 transition"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
          >
            {showMobileMenu ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        
        {/* Mobile date display below header */}
        <div className="block lg:hidden mt-2 text-center">
          <p className="text-xs opacity-90">
            {currentDate}
          </p>
        </div>
      </header>

      {/* Mobile dropdown menu */}
      {showMobileMenu && (
        <div className="lg:hidden bg-blue-400 text-white rounded-b-2xl shadow-lg relative z-50">
          <div className="p-4 space-y-3">
            <button className="w-full flex items-center space-x-3 p-2 rounded hover:bg-blue-500 transition">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span className="text-sm">Benachrichtigungen</span>
            </button>
            <button className="w-full flex items-center space-x-3 p-2 rounded hover:bg-blue-500 transition">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
              <span className="text-sm">Profil</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;